class KeysConstant {
  // Collections
  static const managementUser = 'managementUser';
  static const managerUser = 'managerUser';

  // Enumerators
}

class KeyRoles {
  static const management = "Management";
  static const manager = "Manager";
  static const staff = "Staff";
}
