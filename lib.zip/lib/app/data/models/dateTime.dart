class DateTimeModel{

  String? date;
  String? time;
  DateTimeModel({
    this.date,this.time
  });
}