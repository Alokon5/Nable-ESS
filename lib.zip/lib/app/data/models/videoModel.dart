class VideoScreenModel {
  final String? video;
  final String? title;
  final String? description;
  final String? date;

  VideoScreenModel({
     this.video,
     this.title,
     this.description,
     this.date,
  });
}
