class DatePair {
  final String currentDate;
  final String dateBefore27Days;

  DatePair(this.currentDate, this.dateBefore27Days);
}
