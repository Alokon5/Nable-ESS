class TimeDifference {
  final int hours;
  final int minutes;

  TimeDifference(this.hours, this.minutes);
}
