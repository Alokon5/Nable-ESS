class WorkTimeModel {
  String? date;
  String? checkInTime;
  String? checkOutTime;
  int? workHrsInDay;
  int? workMinInDay;
  String? totalhrsminDay;
  WorkTimeModel(
      {this.date,
      this.checkInTime,
      this.checkOutTime,
      this.workHrsInDay,
      this.workMinInDay,
      this.totalhrsminDay});
}
