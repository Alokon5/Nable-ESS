import 'package:get/get.dart';

import 'controller.dart';

class StaffProfileBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(StaffProfileController());
  }
}
